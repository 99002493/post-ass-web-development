function Form validation(){
    if(document.getElementById("First Name").value==""){
     alert("Enter your First Name");
     document.registerform.username.focus();
     }
     {
        if(document.getElementById("Last Name").value==""){
         alert("Enter your Last Name");
         document.registerform.username.focus();
         }

    else if(document.getElementById("Password").value==""){
     alert("Enter Password");
     document.registerform.password.focus();
     }
     else if(document.getElementById("Email").value==""){
        alert("Enter Email");
        document.registerform.Email.focus();
        }
        else if(document.getElementById("Phone number").value==""){
            alert("Enter Password");
            document.registerform.phonenumber.focus();
            }
    else{
     Form validation();
    // alert("You are successfully registered ");
     
     }
    function Form validation(){
    var uns=["Arvind","Kumar","DR","XYZ"];
    var f=0;
    var uname1=document.getElementById("First Name").value;
    // uname=prompt('Enter username');
    for(let i=0;i<uns.length;i++){
    if(uname1==uns[i])
     {
     
     f=1;
    break;
     }
     
     }
    if(f==1){
     alert("username already exists");
     }
    else{
     document.registerform.submit();
    // document.write('welcome user');
     }